console.log('dcs translit version: ' + chrome.runtime.getManifest().version); 
console.log('extension id: ' + chrome.runtime.id);
